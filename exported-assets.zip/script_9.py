
# Create sample HTML templates for users to reference
sample_question = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .question { margin-bottom: 20px; }
        h2, h3 { color: #333; }
        p { line-height: 1.6; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Question</h2><hr/>
        <div class="question">
            <p>You are designing a cloud architecture for your company's new application. 
            The application requires high availability and automatic scaling. 
            Which Azure service should you use?</p>
        </div>
        <div class="question-choices-container">
            <ul>
                <li class="multi-choice-item">
                    <span class="multi-choice-letter" data-choice-letter="A">A.</span>
                    Azure Virtual Machines
                </li>
                <li class="multi-choice-item correct-hidden">
                    <span class="multi-choice-letter" data-choice-letter="B">B.</span>
                    Azure App Service with autoscaling
                </li>
                <li class="multi-choice-item">
                    <span class="multi-choice-letter" data-choice-letter="C">C.</span>
                    Azure Container Instances
                </li>
                <li class="multi-choice-item">
                    <span class="multi-choice-letter" data-choice-letter="D">D.</span>
                    Azure Kubernetes Service without autoscaling
                </li>
            </ul>
        </div>
    </div>
</body>
</html>'''

sample_answer = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Answer, Discussion, and AI Recommendation</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .answer { margin-bottom: 20px; }
        .discussion-summary { margin-bottom: 20px; }
        .ai-recommendation { margin-top: 20px; }
        h2, h3 { color: #333; }
        p { line-height: 1.6; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Suggested Answer</h2><hr/>
        <div class="answer">
            <p><strong>Suggested Answer:</strong> B</p>
        </div>
        <div class="discussion-summary">
            <h3>Discussion Summary</h3>
            <p><strong>Agree with Suggested Answer</strong> From internet discussions from Q1 2024 to Q3 2024, 
            the consensus is that <strong>B is correct</strong>. Azure App Service with autoscaling provides 
            built-in high availability and automatic scaling capabilities without requiring manual VM management. 
            Multiple community members confirmed this was the correct answer in their actual exams. 
            The service automatically handles load balancing and can scale both vertically and horizontally 
            based on demand.</p>
        </div>
        <hr/><br/>
        <div class="ai-recommendation">
            <h3>AI Recommended Answer</h3>
            <p>
                The <strong>suggested answer B is correct</strong>. <br/>
                <strong>Reasoning:</strong> Azure App Service is a fully managed platform-as-a-service (PaaS) 
                offering that provides built-in high availability and autoscaling capabilities. It automatically 
                manages the infrastructure, including patching, scaling, and load balancing, making it ideal 
                for applications requiring these features without manual intervention.
                <br/>
                <strong>Why other options are incorrect:</strong>
            </p>
            <ul>
                <li>A. Azure Virtual Machines: While VMs can be configured for high availability and scaling, 
                they require manual setup and management of scale sets, load balancers, and availability sets, 
                making them more complex than App Service.</li>
                <li>C. Azure Container Instances: This service is designed for simple container deployments 
                and doesn't include built-in autoscaling or high availability features comparable to App Service.</li>
                <li>D. Azure Kubernetes Service without autoscaling: While AKS is powerful, the question 
                specifically mentions this option without autoscaling, which doesn't meet the requirement. 
                Additionally, AKS requires more management overhead than App Service.</li>
            </ul>
            <p>Citations:</p>
            <ul>
                <li>Azure App Service documentation, https://learn.microsoft.com/en-us/azure/app-service/overview</li>
                <li>Azure App Service autoscaling, https://learn.microsoft.com/en-us/azure/app-service/manage-scale-up</li>
            </ul>
        </div>
    </div>
</body>
</html>'''

# Save sample templates
os.makedirs('sample_question_template', exist_ok=True)
with open('sample_question_template/summary_question.html', 'w', encoding='utf-8') as f:
    f.write(sample_question)

with open('sample_question_template/summary_discussion_ai.html', 'w', encoding='utf-8') as f:
    f.write(sample_answer)

print("✅ Created: sample_question_template/summary_question.html")
print("✅ Created: sample_question_template/summary_discussion_ai.html")
print()
print("📋 Sample templates created for reference!")
